#include "lecture.h"


absorp lecture(FILE* file_pf, int* file_state){

	absorp myAbsorp;
	*file_state=EOF;
	
	return myAbsorp; // return EOF flag

}

